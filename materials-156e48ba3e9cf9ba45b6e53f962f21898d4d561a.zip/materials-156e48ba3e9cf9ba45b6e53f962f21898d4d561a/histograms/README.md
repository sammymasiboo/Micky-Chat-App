# Python Histogram Plotting: Code Snippets

Corresponding code to the Real Python tutorial, "[Python Histogram Plotting: NumPy, Matplotlib, Pandas & Seaborn](https://realpython.com/python-histograms/)."
